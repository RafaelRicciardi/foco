# Modo Intencional — protótipo Android

Projeto inicial em Kotlin para Android 15 / Samsung Galaxy A54.

## O que esta versão já implementa
- Tela minimalista com motivo, duração e seleção de aplicativo.
- Lista de aplicativos instalados que podem ser abertos.
- Abre diretamente o aplicativo escolhido.
- Temporizador em serviço em primeiro plano com notificação de encerramento.
- Registro local de inicialização do aparelho (evento BOOT_COMPLETED), abertura da tela e início/fim de sessão.
- Histórico básico no próprio aparelho.
- Pode ser selecionado como aplicativo de início (launcher) do Android.

## Limitações importantes desta primeira versão
- O Android não permite que um app comum desligue o telefone automaticamente.
- O app não consegue fechar à força o aplicativo escolhido nem impedir totalmente que a pessoa abra outros apps.
- O temporizador notifica ao terminar; não consegue tomar o foco do app em uso de forma garantida.
- A tela de início padrão só aparece automaticamente se o usuário definir este app como launcher padrão. O Android pode retomar o último app após desbloqueio.
- O registro de BOOT_COMPLETED registra a inicialização/reinicialização do aparelho, não cada desbloqueio.
- A permissão QUERY_ALL_PACKAGES pode exigir justificativa/revisão caso o app seja publicado na Play Store.

## Como abrir no Android Studio
1. Instale o Android Studio.
2. Abra a pasta `ModoIntencional`.
3. Aguarde a sincronização do Gradle.
4. Conecte o Galaxy A54 com depuração USB ativada ou use um emulador.
5. Execute `app`.

## Como definir como tela inicial
Depois de instalar, vá a Configurações > Aplicativos > Escolher aplicativos padrão > Aplicativo de início e selecione **Modo Intencional**. Os nomes dos menus podem variar na One UI.

## Próximas etapas recomendadas
- Implementar banco Room e exportação CSV.
- Medir duração real com UsageStats (permissão de acesso ao uso).
- Implementar tela de encerramento e fluxo de bloqueio de tela.
- Avaliar modo quiosque com Device Owner para restringir a navegação.
- Testar consumo de bateria, reinicialização e permissões no Galaxy A54.
