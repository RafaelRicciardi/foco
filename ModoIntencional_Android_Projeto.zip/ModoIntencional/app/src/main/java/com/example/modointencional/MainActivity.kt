package com.example.modointencional

import android.app.Activity
import android.app.AlertDialog
import android.app.NotificationManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class LaunchableApp(val label: String, val packageName: String) {
    override fun toString() = label
}

class MainActivity : Activity() {
    private lateinit var reason: EditText
    private lateinit var minutes: EditText
    private lateinit var appPicker: Spinner
    private var apps: List<LaunchableApp> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestNotificationPermission()
        SessionStore.add(this, "open", detail = "Tela inicial aberta")
        buildHome()
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 10)
        }
    }

    private fun buildHome() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 34, 28, 24)
            setBackgroundColor(Color.rgb(242, 242, 242))
        }
        root.addView(TextView(this).apply {
            text = "MODO INTENCIONAL"
            textSize = 20f
            setTextColor(Color.BLACK)
            letterSpacing = 0.08f
        })
        root.addView(TextView(this).apply {
            text = "Uma tarefa por vez."
            textSize = 13f
            setTextColor(Color.DKGRAY)
            setPadding(0, 4, 0, 28)
        })
        addLabel(root, "Por que você está usando o celular?")
        reason = EditText(this).apply {
            hint = "Descreva a tarefa"
            textSize = 16f
            setSingleLine(false)
            minLines = 2
            setBackgroundColor(Color.WHITE)
            setPadding(12, 10, 12, 10)
        }
        root.addView(reason, matchWidth())
        addLabel(root, "Tempo disponível (minutos)")
        minutes = EditText(this).apply {
            hint = "Ex.: 15"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setSingleLine(true)
            setBackgroundColor(Color.WHITE)
            setPadding(12, 10, 12, 10)
        }
        root.addView(minutes, matchWidth())
        addLabel(root, "Aplicativo que você vai utilizar")
        appPicker = Spinner(this)
        apps = loadApps()
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, apps).also {
            it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }
        appPicker.adapter = adapter
        root.addView(appPicker, matchWidth())

        val start = Button(this).apply {
            text = "INICIAR TAREFA"
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(55, 55, 55))
            setOnClickListener { startTask() }
        }
        val startParams = matchWidth()
        startParams.topMargin = 26
        root.addView(start, startParams)

        val history = Button(this).apply {
            text = "HISTÓRICO"
            setOnClickListener { showHistory() }
        }
        root.addView(history, matchWidth())

        val info = TextView(this).apply {
            text = "Sem recomendações. Sem feed. Apenas a tarefa escolhida."
            textSize = 11f
            setTextColor(Color.GRAY)
            setPadding(0, 24, 0, 0)
        }
        root.addView(info)
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun addLabel(parent: LinearLayout, label: String) {
        parent.addView(TextView(this).apply {
            text = label
            textSize = 14f
            setTextColor(Color.BLACK)
            setPadding(0, 18, 0, 7)
        })
    }

    private fun matchWidth() = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)

    private fun loadApps(): List<LaunchableApp> {
        val intent = Intent(Intent.ACTION_MAIN, null).addCategory(Intent.CATEGORY_LAUNCHER)
        return packageManager.queryIntentActivities(intent, PackageManager.MATCH_ALL)
            .map { LaunchableApp(it.loadLabel(packageManager).toString(), it.activityInfo.packageName) }
            .filter { it.packageName != packageName }
            .distinctBy { it.packageName }
            .sortedBy { it.label.lowercase(Locale.getDefault()) }
    }

    private fun startTask() {
        val why = reason.text.toString().trim()
        val mins = minutes.text.toString().toIntOrNull()
        if (why.isBlank()) { reason.error = "Informe o motivo"; return }
        if (mins == null || mins !in 1..720) { minutes.error = "Informe de 1 a 720 minutos"; return }
        if (apps.isEmpty() || appPicker.selectedItemPosition < 0) return
        val selected = apps[appPicker.selectedItemPosition]
        val endAt = System.currentTimeMillis() + mins * 60_000L
        getSharedPreferences("modo_intencional", MODE_PRIVATE).edit()
            .putString("active_reason", why)
            .putString("active_app", selected.label)
            .putLong("active_start", System.currentTimeMillis())
            .putLong("active_end", endAt)
            .apply()
        SessionStore.add(this, "start", why, selected.label, mins)
        val service = Intent(this, SessionService::class.java).putExtra("endAt", endAt).putExtra("appName", selected.label)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(service) else startService(service)
        val launch = packageManager.getLaunchIntentForPackage(selected.packageName)
        if (launch != null) startActivity(launch) else Toast.makeText(this, "Não foi possível abrir o aplicativo.", Toast.LENGTH_SHORT).show()
    }

    private fun showHistory() {
        val items = SessionStore.history(this)
        AlertDialog.Builder(this)
            .setTitle("Histórico de utilização")
            .setMessage(if (items.isEmpty()) "Ainda não há registros." else items.joinToString("\n\n"))
            .setPositiveButton("FECHAR", null)
            .show()
    }

    override fun onResume() {
        super.onResume()
        val prefs = getSharedPreferences("modo_intencional", MODE_PRIVATE)
        val end = prefs.getLong("active_end", 0L)
        if (end > 0L && System.currentTimeMillis() >= end) {
            prefs.edit().putLong("active_end", 0L).apply()
            AlertDialog.Builder(this)
                .setTitle("Tempo encerrado")
                .setMessage("O tempo planejado terminou. Deseja registrar a conclusão da tarefa?")
                .setPositiveButton("CONCLUIR") { _, _ ->
                    SessionStore.add(this, "end", app = prefs.getString("active_app", "") ?: "", detail = "Tarefa concluída pelo usuário")
                    Toast.makeText(this, "Sessão registrada.", Toast.LENGTH_SHORT).show()
                }
                .setNegativeButton("AINDA NÃO") { _, _ ->
                    SessionStore.add(this, "other", detail = "Sessão não concluída no tempo planejado")
                }.show()
        }
    }
}
