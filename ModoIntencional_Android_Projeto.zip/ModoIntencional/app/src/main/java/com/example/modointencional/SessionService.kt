package com.example.modointencional

import android.app.*
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat

class SessionService : Service() {
    private val channelId = "modo_intencional_timer"
    private var endAt: Long = 0L
    private var appName: String = ""

    override fun onCreate() {
        super.onCreate()
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(channelId, "Temporizador de tarefa", NotificationManager.IMPORTANCE_HIGH)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        endAt = intent?.getLongExtra("endAt", 0L) ?: 0L
        appName = intent?.getStringExtra("appName") ?: "aplicativo"
        startForeground(41, notification("Sessão em andamento: $appName"))
        val delay = (endAt - System.currentTimeMillis()).coerceAtLeast(0L)
        Thread {
            try { Thread.sleep(delay) } catch (_: InterruptedException) {}
            if (endAt > 0L && System.currentTimeMillis() >= endAt) {
                SessionStore.add(this, "end", app = appName)
                val done = notification("Tempo planejado encerrado. Volte ao Modo Intencional para concluir.")
                getSystemService(NotificationManager::class.java).notify(42, done)
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
        }.start()
        return START_NOT_STICKY
    }

    private fun notification(message: String): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, channelId)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("Modo Intencional")
            .setContentText(message)
            .setContentIntent(open)
            .setAutoCancel(true)
            .setOngoing(message.startsWith("Sessão"))
            .build()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
