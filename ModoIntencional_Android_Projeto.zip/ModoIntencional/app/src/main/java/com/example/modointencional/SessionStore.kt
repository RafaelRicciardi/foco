package com.example.modointencional

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object SessionStore {
    private const val PREFS = "modo_intencional"
    private const val KEY_LOG = "events"

    fun add(context: Context, type: String, reason: String = "", app: String = "", planned: Int = 0, detail: String = "") {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val array = try { JSONArray(prefs.getString(KEY_LOG, "[]")) } catch (_: Exception) { JSONArray() }
        val item = JSONObject().apply {
            put("time", System.currentTimeMillis())
            put("type", type)
            put("reason", reason)
            put("app", app)
            put("planned", planned)
            put("detail", detail)
        }
        array.put(item)
        prefs.edit().putString(KEY_LOG, array.toString()).apply()
    }

    fun history(context: Context): List<String> {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val array = try { JSONArray(prefs.getString(KEY_LOG, "[]")) } catch (_: Exception) { JSONArray() }
        val fmt = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())
        return (0 until array.length()).map { i ->
            val o = array.getJSONObject(i)
            val date = fmt.format(Date(o.optLong("time")))
            when (o.optString("type")) {
                "boot" -> "$date  •  Celular ligado"
                "start" -> "$date  •  Início: ${o.optString("reason")} | ${o.optString("app")} | ${o.optInt("planned")} min"
                "end" -> "$date  •  Tempo planejado encerrado: ${o.optString("app")}"
                else -> "$date  •  ${o.optString("detail")}"
            }
        }.reversed()
    }
}
