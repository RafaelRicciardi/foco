package com.example.foco

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class Sessao(
    val id: Long, val motivo: String, val app: String,
    val inicio: Long, val minutos: Int, val fim: Long
)

class Db(ctx: Context) : SQLiteOpenHelper(ctx.applicationContext, "foco.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE sessoes(id INTEGER PRIMARY KEY AUTOINCREMENT, motivo TEXT, " +
                "app TEXT, inicio INTEGER, minutos INTEGER, fim INTEGER DEFAULT 0)"
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, o: Int, n: Int) {}

    fun inserir(motivo: String, app: String, inicio: Long, minutos: Int): Long {
        val v = ContentValues().apply {
            put("motivo", motivo); put("app", app); put("inicio", inicio); put("minutos", minutos)
        }
        return writableDatabase.insert("sessoes", null, v)
    }

    fun encerrar(id: Long, fim: Long) {
        val v = ContentValues().apply { put("fim", fim) }
        writableDatabase.update("sessoes", v, "id=?", arrayOf(id.toString()))
    }

    fun listar(): List<Sessao> {
        val out = mutableListOf<Sessao>()
        readableDatabase.rawQuery(
            "SELECT id,motivo,app,inicio,minutos,fim FROM sessoes ORDER BY inicio DESC", null
        ).use { c ->
            while (c.moveToNext()) out += Sessao(
                c.getLong(0), c.getString(1), c.getString(2),
                c.getLong(3), c.getInt(4), c.getLong(5)
            )
        }
        return out
    }
}
