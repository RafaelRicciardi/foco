package com.example.foco

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent

class PowerService : AccessibilityService() {
    companion object {
        var instance: PowerService? = null
    }

    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: android.content.Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    /** Abre o menu de desligar. Se você cancelar, bloqueia a tela após 30 s. */
    fun menuDesligar(ctx: Context) {
        performGlobalAction(GLOBAL_ACTION_POWER_DIALOG)
        if (Build.VERSION.SDK_INT >= 28) {
            Handler(Looper.getMainLooper()).postDelayed({
                if (!Controle.ativa(ctx)) performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN)
            }, 30_000)
        }
    }
}
