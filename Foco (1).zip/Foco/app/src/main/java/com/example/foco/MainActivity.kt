package com.example.foco

import android.app.NotificationManager
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(Modifier.fillMaxSize()) { Raiz() }
            }
        }
    }
}

@Composable
fun Raiz() {
    val ctx = LocalContext.current
    var agora by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var historico by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        while (true) {
            agora = System.currentTimeMillis()
            // Caso o alarme tenha se perdido (ex.: reinício do aparelho)
            if (Controle.ativa(ctx) && agora >= Controle.fimEm(ctx)) Controle.encerrar(ctx)
            delay(1000)
        }
    }

    Column(Modifier.fillMaxSize().systemBarsPadding().padding(24.dp)) {
        when {
            historico -> Historico { historico = false }
            Controle.ativa(ctx) -> Ativa(agora) { agora = System.currentTimeMillis() }
            else -> Form({ historico = true }) { agora = System.currentTimeMillis() }
        }
    }
}

@Composable
fun Form(onHistorico: () -> Unit, onMudou: () -> Unit) {
    val ctx = LocalContext.current
    var motivo by remember { mutableStateOf("") }
    var minutos by remember { mutableStateOf("") }
    var app by remember { mutableStateOf("") }
    var erro by remember { mutableStateOf("") }
    val full = Modifier.fillMaxWidth()

    Text("Foco", style = MaterialTheme.typography.headlineMedium)
    Spacer(Modifier.height(16.dp))

    if (PowerService.instance == null) {
        Text("Ative o serviço de acessibilidade \"Foco\" para o menu de desligar funcionar.")
        TextButton(onClick = {
            ctx.startActivity(
                Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }) { Text("Abrir configurações de acessibilidade") }
    }
    val nm = ctx.getSystemService(NotificationManager::class.java)
    if (!nm.isNotificationPolicyAccessGranted) {
        TextButton(onClick = {
            ctx.startActivity(
                Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }) { Text("Permitir bloquear notificações durante a tarefa") }
    }

    OutlinedTextField(motivo, { motivo = it }, full,
        label = { Text("Por que estou usando o celular?") })
    Spacer(Modifier.height(12.dp))
    OutlinedTextField(minutos, { minutos = it.filter(Char::isDigit) }, full,
        label = { Text("Tempo para a tarefa (minutos)") },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
    Spacer(Modifier.height(12.dp))
    OutlinedTextField(app, { app = it }, full,
        label = { Text("Aplicativo que vou usar") }, singleLine = true)
    Spacer(Modifier.height(16.dp))

    if (erro.isNotEmpty()) Text(erro, color = MaterialTheme.colorScheme.error)

    Button(full, onClick = {
        val m = minutos.toIntOrNull()
        erro = when {
            motivo.isBlank() -> "Diga o motivo."
            m == null || m < 1 || m > 240 -> "Tempo entre 1 e 240 minutos."
            app.isBlank() -> "Diga qual aplicativo."
            else -> Controle.iniciar(ctx, motivo.trim(), app.trim(), m) ?: ""
        }
        onMudou()
    }) { Text("Começar") }

    Spacer(Modifier.weight(1f))
    TextButton(onClick = onHistorico) { Text("Histórico") }
}

@Composable
fun Ativa(agora: Long, onMudou: () -> Unit) {
    val ctx = LocalContext.current
    val resta = ((Controle.fimEm(ctx) - agora) / 1000).coerceAtLeast(0)
    Text("Tarefa em andamento", style = MaterialTheme.typography.headlineMedium)
    Spacer(Modifier.height(16.dp))
    Text("Motivo: ${Controle.motivo(ctx)}")
    Text("Aplicativo: ${Controle.app(ctx)}")
    Spacer(Modifier.height(24.dp))
    Text("%02d:%02d".format(resta / 60, resta % 60), style = MaterialTheme.typography.displayLarge)
    Spacer(Modifier.height(24.dp))
    Button(Modifier.fillMaxWidth(), onClick = { Controle.encerrar(ctx); onMudou() }) {
        Text("Terminei, desligar")
    }
}

@Composable
fun Historico(onVoltar: () -> Unit) {
    val ctx = LocalContext.current
    val itens = remember { Db(ctx).listar() }
    val fmt = remember { SimpleDateFormat("dd/MM HH:mm", Locale.getDefault()) }
    TextButton(onClick = onVoltar) { Text("← Voltar") }
    Text("Histórico", style = MaterialTheme.typography.headlineMedium)
    Spacer(Modifier.height(12.dp))
    LazyColumn {
        items(itens) { s ->
            val usou = if (s.fim > 0) "${(s.fim - s.inicio) / 60_000} min" else "—"
            Text("${fmt.format(Date(s.inicio))} · ${s.app}", style = MaterialTheme.typography.titleSmall)
            Text("${s.motivo}\nPlanejado: ${s.minutos} min · Usado: $usou")
            HorizontalDivider(Modifier.padding(vertical = 10.dp))
        }
    }
}
