package com.example.foco

import android.app.AlarmManager
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

object Controle {
    private fun prefs(c: Context) = c.getSharedPreferences("estado", Context.MODE_PRIVATE)

    fun ativa(c: Context) = prefs(c).getLong("id", 0L) != 0L
    fun fimEm(c: Context) = prefs(c).getLong("fim", 0L)
    fun motivo(c: Context) = prefs(c).getString("motivo", "") ?: ""
    fun app(c: Context) = prefs(c).getString("app", "") ?: ""

    private fun alarmeIntent(c: Context) = PendingIntent.getBroadcast(
        c, 1, Intent(c, AlarmReceiver::class.java),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    /** Retorna uma mensagem de erro, ou null se deu certo. */
    fun iniciar(c: Context, motivo: String, nomeApp: String, minutos: Int): String? {
        val pm = c.packageManager
        val lista = pm.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0
        ).filter { it.activityInfo.packageName != c.packageName }
        val alvo = lista.firstOrNull { it.loadLabel(pm).toString().equals(nomeApp, true) }
            ?: lista.firstOrNull { it.loadLabel(pm).toString().startsWith(nomeApp, true) }
            ?: lista.firstOrNull { it.loadLabel(pm).toString().contains(nomeApp, true) }
            ?: return "Aplicativo não encontrado."
        val launch = pm.getLaunchIntentForPackage(alvo.activityInfo.packageName)
            ?: return "Não foi possível abrir esse aplicativo."

        val nomeReal = alvo.loadLabel(pm).toString()
        val agora = System.currentTimeMillis()
        val fim = agora + minutos * 60_000L
        val id = Db(c).inserir(motivo, nomeReal, agora, minutos)

        prefs(c).edit()
            .putLong("id", id).putLong("fim", fim)
            .putString("motivo", motivo).putString("app", nomeReal).apply()

        val am = c.getSystemService(AlarmManager::class.java)
        val abrir = PendingIntent.getActivity(
            c, 2, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        am.setAlarmClock(AlarmManager.AlarmClockInfo(fim, abrir), alarmeIntent(c))

        dnd(c, true)
        c.startActivity(launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return null
    }

    /** Fecha o registro, cancela o alarme e abre o menu de desligar. */
    fun encerrar(c: Context) {
        val p = prefs(c)
        val id = p.getLong("id", 0L)
        if (id == 0L) return
        Db(c).encerrar(id, System.currentTimeMillis())
        p.edit().clear().apply()
        c.getSystemService(AlarmManager::class.java).cancel(alarmeIntent(c))
        dnd(c, false)
        PowerService.instance?.menuDesligar(c.applicationContext)
    }

    /** Modo "Não perturbe" (só alarmes), se o usuário tiver dado a permissão. */
    fun dnd(c: Context, ligar: Boolean) {
        val nm = c.getSystemService(NotificationManager::class.java)
        if (!nm.isNotificationPolicyAccessGranted) return
        nm.setInterruptionFilter(
            if (ligar) NotificationManager.INTERRUPTION_FILTER_ALARMS
            else NotificationManager.INTERRUPTION_FILTER_ALL
        )
    }
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) = Controle.encerrar(c.applicationContext)
}
